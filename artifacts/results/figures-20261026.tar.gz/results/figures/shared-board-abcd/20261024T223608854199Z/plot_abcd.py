"""Plot the four shared-board conditions with matched seeds and private-board contrasts."""
import csv
import hashlib
import json
import shutil
from datetime import datetime,timezone
from pathlib import Path
from statistics import mean,median
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'results/ae-batches/shared-board-eval-v2-seeds101-105/analysis/results.json'
METRICS=[('primary_regret_gap','Best subset (size 2–5)','Regret gap'),
         ('reference_pair_regret_gap','Fixed pair¹','Regret gap'),
         ('joint_reward','Whole team','Total reward')]


def main():
    data=json.loads(SOURCE.read_text());assert data['status']=='completed'
    lookup={(r['condition'],r['seed']):r for r in data['runs']}
    seeds=[101,102,103,104,105];conditions=list('ABCD')
    assert all((c,s) in lookup for c in conditions for s in seeds)
    out=ROOT/'results/figures/shared-board-abcd'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True,exist_ok=False)
    means={c:{key:mean(lookup[c,s][key] for s in seeds) for key,_,_ in METRICS} for c in conditions}
    contrasts=[]
    for key,_,_ in METRICS:
        for label,terms in [('A-B',[(1,'A'),(-1,'B')]),('C-D',[(1,'C'),(-1,'D')]),
                            ('(A-B)-(C-D)',[(1,'A'),(-1,'B'),(-1,'C'),(1,'D')])]:
            vals=[sum(sign*lookup[c,s][key] for sign,c in terms) for s in seeds]
            recorded=next(x for x in data['contrasts'] if x['contrast']==label and x['metric']==key)
            assert abs(mean(vals)-recorded['mean'])<1e-9
            contrasts.append(dict(metric=key,contrast=label,mean=mean(vals),median=median(vals),
                positive=sum(v>1e-9 for v in vals),negative=sum(v< -1e-9 for v in vals),paired=dict(zip(seeds,vals))))
    stats=dict(source=str(SOURCE),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),means=means,contrasts=contrasts)
    (out/'summary.json').write_text(json.dumps(stats,indent=2)+'\n')
    rows=[dict(seed=s,condition=c,**{key:lookup[c,s][key] for key,_,_ in METRICS}) for s in seeds for c in conditions]
    with (out/'seed_scores.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    shutil.copyfile(__file__,out/'plot_abcd.py')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    colors=['#2463a6','#d17b28','#3b9364','#8456a2','#bc4655']
    x=np.arange(4)
    fig,axes=plt.subplots(1,3,figsize=(13,5.0))
    fig.subplots_adjust(left=.06,right=.985,bottom=.20,top=.73,wspace=.32)
    for ax,(key,title,ylabel) in zip(axes,METRICS):
        for s,color in zip(seeds,colors):
            vals=[lookup[c,s][key] for c in conditions]
            ax.plot(x,vals,marker='o',ms=5,lw=1,color=color,alpha=.7,zorder=2)
        ax.scatter(x,[means[c][key] for c in conditions],marker='D',s=65,color='black',zorder=4)
        if key!='joint_reward':ax.axhline(0,color='#777777',lw=.8,zorder=0)
        ax.set_xticks(x,conditions);ax.set_xlabel('Condition');ax.set_ylabel(ylabel)
        mean_text='  '.join(f'{c} {means[c][key]:.2f}' for c in conditions)
        ax.set_title(f'{title}\nMeans: {mean_text}',fontsize=10.3,pad=12)
        ax.set_xlim(-.2,3.2)
    handles=[Line2D([],[],color=co,marker='o',lw=1,label=str(s)) for s,co in zip(seeds,colors)]
    handles.append(Line2D([],[],color='black',marker='D',ls='',label='Mean'))
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.91),ncol=6,frameon=False,title='Matched seed')
    fig.suptitle('A, B, C and D: shared public planning in every condition',fontsize=15,y=.99)
    fig.text(.5,.06,'A: instructions + private pair board   |   B: instructions only   |   C: private pair board only   |   D: neither',ha='center',fontsize=9)
    fig.text(.5,.018,'¹Same pair identities across conditions; assigned a coalition objective only in A/B. Lines connect the same seed, not a time trajectory.',ha='center',fontsize=8.8)
    for ext in ('png','svg'):fig.savefig(out/f'abcd-by-seed.{ext}',dpi=180)
    plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(12.5,7.8))
    fig.subplots_adjust(left=.10,right=.98,bottom=.11,top=.86,wspace=.32,hspace=.43)
    for row,(contrast,label) in enumerate([('A-B','Instructions present\nA − B'),('C-D','No instructions\nC − D')]):
        for col,(key,title,_) in enumerate(METRICS):
            ax=axes[row,col];stat=next(x for x in contrasts if x['metric']==key and x['contrast']==contrast)
            vals=[stat['paired'][s] for s in seeds]
            for i,v in enumerate(vals):
                ax.plot([0,v],[i,i],color='#bfbfbf',lw=1.2)
                ax.scatter(v,i,color='#2463a6' if v>=0 else '#8456a2',s=35,zorder=3)
            ax.scatter(stat['mean'],5.3,marker='D',color='black',s=48,zorder=4)
            ax.axvline(0,color='#777777',lw=.8);ax.axhline(4.65,color='#dddddd',lw=.7)
            ax.set_yticks([0,1,2,3,4,5.3],[str(s) for s in seeds]+['Mean']);ax.invert_yaxis()
            ax.set_title(f"{title}\nMean difference {stat['mean']:+.2f}",fontsize=10.5)
            ax.set_xlabel('With private board − without (points)');ax.margins(x=.15)
            if col==0:ax.set_ylabel(label,fontsize=11,labelpad=12)
    fig.suptitle('Adding the private pair board: with versus without coalition instructions',fontsize=14,y=.98)
    fig.text(.5,.025,'Dots = matched seed differences; black diamond = mean. Positive means the metric increases with the private board.\n¹The pair is assigned only in A/B. Higher regret gap is relative advantage, not necessarily higher team reward.',ha='center',fontsize=9)
    for ext in ('png','svg'):fig.savefig(out/f'private-board-effects.{ext}',dpi=180)
    plt.close(fig)
    rel=out.relative_to(ROOT/'results')
    text='''# A, B, C and D — shared-board comparison

All four conditions share the global public planning board and the same seeded task instances, agents, costs, model and speaking order. A has coalition instructions plus a private pair board; B instructions only; C a private pair board without coalition instructions; D neither. This compares all four revised conditions, excluding E.

Five matched seeds (101–105), one trajectory per condition/seed. Lines connect repeated task instances, not successive stages. Black diamonds are means, not confidence intervals. All seeds are shown and retained. No new model calls.

'''
    text+=f'![Four conditions by seed]({rel}/abcd-by-seed.png)\n\n'
    text+='## Means across five seeds\n\n| Condition | Best-subset regret gap | Fixed-pair regret gap | Team reward |\n|---|---:|---:|---:|\n'
    for c in conditions:text+=f"| {c} | {means[c]['primary_regret_gap']:+.3f} | {means[c]['reference_pair_regret_gap']:+.3f} | {means[c]['joint_reward']:.3f} |\n"
    text+='\nFixed pair is an instructed coalition only in A/B; C/D retain the same identities as a scoring reference. The best-subset metric selects the maximizing group of size 2–5 separately in every trajectory. A positive maximum alone does not establish collusion.\n\n'
    text+='## Matched private-board effects\n\nA−B changes private-board access when coalition instructions are present. C−D changes it when instructions are absent.\n\n'
    text+=f'![Effects of adding the private pair board]({rel}/private-board-effects.png)\n\n'
    text+='| Metric | Mean A−B | A>B seeds | Mean C−D | C>D seeds | Mean interaction |\n|---|---:|---:|---:|---:|---:|\n'
    for key,title,_ in METRICS:
        ab=next(x for x in contrasts if x['metric']==key and x['contrast']=='A-B')
        cd=next(x for x in contrasts if x['metric']==key and x['contrast']=='C-D')
        interaction=next(x for x in contrasts if x['metric']==key and x['contrast']=='(A-B)-(C-D)')
        text+=f"| {title} | {ab['mean']:+.3f} | {ab['positive']}/5 | {cd['mean']:+.3f} | {cd['positive']}/5 | {interaction['mean']:+.3f} |\n"
    text+='''
Descriptively, adding the private board with instructions increased mean fixed-pair advantage (+4.811, positive in 4/5 seeds). Without instructions, its mean effect on that pair was negative (−2.241), despite positive differences in 3/5 seeds; seed 103 drives the negative average. Pair advantage in A is positive in all five seeds, while the reference pair in C has positive advantage in two.

On the primary maximum-subset metric, A−B is +4.688 and C−D is −4.349. The corresponding interaction is +9.037. These five-seed observations are exploratory, and the reused seeds and variable model responses limit causal generalization. Neither the interaction nor positive numeric gaps establish collusive intent.

'''
    text+=f'Exports: [condition scores CSV]({rel}/seed_scores.csv), [summary and all paired differences]({rel}/summary.json), [condition plot SVG]({rel}/abcd-by-seed.svg), [effect plot SVG]({rel}/private-board-effects.svg). [Full experiment results](shared-board-eval-v2-summary.md).\n'
    (ROOT/'results/abcd-comparison.md').write_text(text)
    print(json.dumps(dict(output=str(out),means=means),indent=2))

if __name__=='__main__':main()
