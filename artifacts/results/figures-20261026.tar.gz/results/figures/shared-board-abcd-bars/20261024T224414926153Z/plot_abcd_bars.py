"""Bar charts with sample standard deviation across seeds for the shared-board A–D comparison."""
import csv
import hashlib
import json
import shutil
from datetime import datetime,timezone
from pathlib import Path
from statistics import mean, stdev
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'results/ae-batches/shared-board-eval-v2-seeds101-105/analysis/results.json'

def main():
    data=json.loads(SOURCE.read_text());assert data['status']=='completed'
    lookup={(r['condition'],r['seed']):r for r in data['runs']}
    conditions=list('ABCD');seeds=[101,102,103,104,105]
    metrics=[('primary_regret_gap','Best subset (size 2–5)','Mean regret gap'),
             ('reference_pair_regret_gap','Same fixed pair¹','Mean regret gap'),
             ('joint_reward','Whole team','Mean total reward')]
    out=ROOT/'results/figures/shared-board-abcd-bars'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True,exist_ok=False)
    colors=['#2463a6','#d17b28','#3b9364','#8456a2']
    fig,axes=plt.subplots(1,3,figsize=(12.8,5.0))
    fig.subplots_adjust(left=.065,right=.985,bottom=.21,top=.77,wspace=.32)
    rows=[]
    for ax,(metric,title,ylabel) in zip(axes,metrics):
        values=[[lookup[c,s][metric] for s in seeds] for c in conditions]
        means=[mean(v) for v in values]
        sds=[stdev(v) for v in values]
        bars=ax.bar(np.arange(4),means,yerr=sds,capsize=6,
                    error_kw={'ecolor':'#222222','elinewidth':1.5,'capthick':1.5},
                    color=colors,alpha=.78,width=.66,zorder=2)
        all_values=[0]+[bound for mu,sd in zip(means,sds) for bound in (mu-sd,mu+sd)]
        span=max(all_values)-min(all_values);padding=.035*span
        for i,(bar,mu,sd,vs) in enumerate(zip(bars,means,sds,values)):
            ax.text(i,mu+sd+padding,f'{mu:+.2f}' if metric!='joint_reward' else f'{mu:.2f}',
                    ha='center',va='bottom',fontsize=10,fontweight='bold',zorder=5)
            for seed,value in zip(seeds,vs):rows.append(dict(condition=conditions[i],seed=seed,metric=metric,value=value,condition_mean=mu,condition_sample_sd=sd,n_seeds=len(vs),error_lower=mu-sd,error_upper=mu+sd))
        ax.axhline(0,color='#555555',lw=.9,zorder=3)
        ax.set_xticks(range(4),conditions);ax.set_xlabel('Condition');ax.set_ylabel(ylabel)
        ax.set_title(title,fontsize=12,pad=14)
        ax.set_ylim(min(all_values)-.12*span,max(all_values)+.16*span)
        ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
        ax.grid(axis='y',color='#eeeeee',lw=.6,zorder=0);ax.set_axisbelow(True)
    fig.suptitle('A–D comparison: means across five matched seeds',fontsize=15,y=.98)
    fig.text(.5,.88,'Bars: mean   |   Capped lines: ±1 sample standard deviation across seeds (n = 5)',ha='center',fontsize=11)
    fig.text(.5,.075,'A: instructions + private pair board   |   B: instructions only   |   C: private pair board only   |   D: neither',ha='center',fontsize=9)
    fig.text(.5,.025,'All conditions share a global board. Seeds 101–105; error bars show variation, not confidence intervals.\n¹The same pair is assigned a coalition objective only in A/B; C/D use it as a scoring reference.',ha='center',fontsize=8.8)
    for ext in ('png','svg'):fig.savefig(out/f'abcd-bars.{ext}',dpi=180)
    plt.close(fig)
    with (out/'bar_chart_data.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (out/'provenance.json').write_text(json.dumps(dict(source=str(SOURCE),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),seeds=seeds,conditions=conditions,aggregation='arithmetic mean; capped error bars = mean ± one sample standard deviation (ddof=1), n=5; not confidence intervals'),indent=2)+'\n')
    shutil.copyfile(__file__,out/'plot_abcd_bars.py')
    report=ROOT/'results/abcd-comparison.md';text=report.read_text();rel=out.relative_to(ROOT/'results')
    text=text.split('\n## Bar-chart view')[0]
    text+='\n## Bar-chart view\n\nBars show means; capped lines show ±1 sample standard deviation across all five matched seeds (101–105). These describe seed-to-seed variation, not confidence intervals. Separate bars do not estimate uncertainty in paired condition differences; use the paired comparison plots above for those contrasts.\n\n'
    text+=f'![A–D mean bar charts with sample standard deviation]({rel}/abcd-bars.png)\n\n[SVG export]({rel}/abcd-bars.svg) · [Chart data]({rel}/bar_chart_data.csv).\n'
    report.write_text(text)
    print(str(out))

if __name__=='__main__':main()
