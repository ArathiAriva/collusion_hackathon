"""Separate descriptive A–D figures, with an exact team-optimum reference."""
import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean, stdev

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'results/ae-batches/shared-board-eval-v2-seeds101-105/analysis/results.json'


def main():
    data = json.loads(SOURCE.read_text())
    assert data['status'] == 'completed'
    conditions = list('ABCD')
    seeds = list(range(101, 106))
    lookup = {(r['condition'], r['seed']): r for r in data['runs']}
    optima = []
    for seed in seeds:
        matched = [lookup[c, seed]['optimal_reward'] for c in conditions]
        assert max(matched) - min(matched) < 1e-8, (seed, matched)
        optima.append(matched[0])
    optimum_mean = mean(optima)
    out = ROOT / 'results/figures/shared-board-abcd-separate' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True, exist_ok=False)
    colors = ['#2463a6', '#d17b28', '#3b9364', '#8456a2']
    rows = []
    metrics = [
        ('reference_pair_regret_gap', 'fixed-pair', 'Advantage of the same fixed pair', 'Mean regret gap'),
        ('joint_reward', 'team-reward', 'Whole-team reward versus the task optimum', 'Mean total reward'),
        ('primary_regret_gap', 'best-subset-supplement', 'Best-subset advantage (supplementary)', 'Mean maximum regret gap'),
    ]
    for metric, name, title, ylabel in metrics:
        values = [[lookup[c, s][metric] for s in seeds] for c in conditions]
        means = [mean(v) for v in values]
        sds = [stdev(v) for v in values]
        fig, ax = plt.subplots(figsize=(8, 7))
        fig.subplots_adjust(left=.13, right=.96, bottom=.34, top=.77)
        ax.bar(range(4), means, yerr=sds, capsize=7, width=.6, color=colors, alpha=.82,
               error_kw={'ecolor': '#222222', 'elinewidth': 1.6, 'capthick': 1.6}, zorder=3)
        bounds = [0] + [b for mu, sd in zip(means, sds) for b in (mu-sd, mu+sd)]
        if metric == 'joint_reward':
            bounds.append(optimum_mean)
            ax.axhline(optimum_mean, color='#333333', linestyle='--', lw=1.6, zorder=2)
            fig.text(.5, .83, f'Dashed line: mean exact optimum = {optimum_mean:.2f}',
                     ha='center', fontsize=11)
        span = max(bounds) - min(bounds)
        for i, (mu, sd) in enumerate(zip(means, sds)):
            label = f'{mu:.2f}' if metric == 'joint_reward' else f'{mu:+.2f}'
            ax.text(i, mu+sd+.035*span, label, ha='center', va='bottom', fontsize=12, weight='bold')
            for seed, value in zip(seeds, values[i]):
                rows.append(dict(metric=metric, condition=conditions[i], seed=seed, value=value,
                                 mean=mu, sample_sd=sd, n=5, optimal_team_reward=lookup[conditions[i],seed]['optimal_reward']))
        ax.set_ylim(min(bounds)-.09*span, max(bounds)+.19*span)
        if metric == 'joint_reward':
            ax.set_ylim(bottom=0)
        ax.axhline(0, color='#555555', lw=.9, zorder=2)
        ax.set_xticks(range(4), conditions, fontsize=12)
        ax.set_xlabel('Condition', fontsize=11)
        ax.set_ylabel(ylabel, fontsize=12)
        ax.spines[['top', 'right']].set_visible(False)
        ax.grid(axis='y', color='#eeeeee', lw=.7)
        ax.set_axisbelow(True)
        fig.suptitle(title, fontsize=16, y=.97)
        fig.text(.5, .90, 'Means ±1 sample SD across five matched seeds (101–105)', ha='center', fontsize=11)
        fig.text(.5, .16, 'A: instructions + private board     B: instructions only\nC: private board only     D: neither\nAll conditions share a global planning board.', ha='center', fontsize=10, linespacing=1.45)
        note = {
            'reference_pair_regret_gap': 'Positive gap: pair has lower mean regret than outsiders.\nThe pair has coalition instructions only in A/B; C/D use the same identities.',
            'joint_reward': 'Dashed line: mean of the five seed-specific exact optimal team rewards.\nEach optimum is shared across A–D for that seed.',
            'primary_regret_gap': 'The maximizing subset (size 2–5) is selected separately in each run.\nA positive maximum alone does not establish collusion.',
        }[metric]
        fig.text(.5, .045, note+'\nError bars describe seed variation, not confidence intervals.', ha='center', fontsize=9, linespacing=1.4)
        for ext in ('png', 'svg'):
            fig.savefig(out / f'{name}.{ext}', dpi=180)
        plt.close(fig)
    with (out / 'chart_data.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    provenance = dict(source=str(SOURCE), source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                      seeds=seeds, conditions=conditions, error_bars='±1 sample SD (ddof=1), n=5',
                      seed_optima=dict(zip(seeds, optima)), mean_exact_optimal_team_reward=optimum_mean,
                      optimum_matches_conditions=True)
    (out / 'provenance.json').write_text(json.dumps(provenance, indent=2)+'\n')
    shutil.copyfile(__file__, out / Path(__file__).name)
    report = ROOT / 'results/abcd-comparison.md'
    text = report.read_text().split('\n## Separate chart images')[0]
    rel = out.relative_to(ROOT / 'results')
    text += f'''\n## Separate chart images

These descriptive charts retain all five seeds and use mean ±1 sample SD. The best-subset chart is supplementary because selecting the strongest subset alone does not establish collusion.

![Fixed-pair advantage]({rel}/fixed-pair.png)

![Whole-team reward with mean exact optimum]({rel}/team-reward.png)

The team reference is the mean of five exact seed-specific optima: **{optimum_mean:.3f}**. Each seed's optimum was verified identical across A–D. This is an average feasibility benchmark; individual seeds have different optima. It is not the mean of observed best outcomes.

[Fixed-pair SVG]({rel}/fixed-pair.svg) · [Team-reward SVG]({rel}/team-reward.svg) · [Supplementary best-subset PNG]({rel}/best-subset-supplement.png) · [Chart data]({rel}/chart_data.csv) · [Provenance and individual optima]({rel}/provenance.json).
'''
    report.write_text(text)
    print(json.dumps({'output': str(out), 'mean_optimal_reward': optimum_mean, 'seed_optima': optima}, indent=2))


if __name__ == '__main__':
    main()
