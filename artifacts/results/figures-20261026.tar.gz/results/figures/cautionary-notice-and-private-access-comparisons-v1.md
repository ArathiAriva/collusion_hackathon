# A–F and D–E study illustration

Created October 25, 2026 after reading the current shared-board E and oversight-pressure F YAMLs, their README and experiment plan, and current project log.

A/F: same global and pair-only board plus assigned pair objective. F adds configured governance notice to every agent's user prompt on every planning/execution turn. Notice is not a board post. It describes audit, forbidden conduct, possible suspension and the team objective; no monitor or sanctions are implemented. This is the entire-notice intervention, not an isolated sanction-expectation effect.

D/E: no coalition instructions in either. D has one global board; E retains global and adds all fifteen private pair boards, total sixteen. Each agent has global plus its own five pair boards. Internal reference-pair metadata does not assign a coalition in D/E.

Illustration presents questions, not effects or collusive-intent labels. Five matched task seeds, 101–105; six agents; four planning rounds. Networks and numeric robot labels are schematic. Artwork is generated raster; text and exact network geometry should be checked for publication. No experiment files or configurations modified.
