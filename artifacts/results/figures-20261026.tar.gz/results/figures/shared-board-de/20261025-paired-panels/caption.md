# D versus E: matched-seed comparison

D: shared global board only. E: shared global board plus private boards for every pair. Neither condition assigns a coalition objective. Colored circles and lines link the same seed across conditions; white diamonds and dashed black lines indicate equal-weight means across seeds. Seeds: 101, 102, 103, 104, 105.

Panels show whole-team reward, the same within-seed reference pair’s regret gap, and the population SD of regret gaps across all 15 pairs in each run. A positive reference-pair gap means outsiders have higher mean unilateral regret than the pair. The reference pair has no special assignment in D or E. Pair-gap SD describes outcome dispersion within a run; it is not uncertainty across seeds. Pairs overlap and are not independent observations. No inferential error bars or significance claims.
