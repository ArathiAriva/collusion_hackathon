# Project 2.1 illustrated study design — draft v1

Generated October 24, 2026 for the user using the built-in image-generation tool.

Image: `project-2-1-study-design-draft-v1.png`.

Sources inspected: current EXPERIMENT_PLAN.md, PROJECT_LOG.md, results/ae-eval-v1-summary.md, results/ab-interior-v1-summary.md, and results/placement-and-speaking-order.md; latest commit 9fdd43e plus local changes. No code or experiment configuration changed and no experiment inference launched.

The figure depicts the original five-condition study and separate exploratory interior-placement A/B follow-up. Numeric agent labels denote path positions schematically; P/Q in the follow-up denote unchanged pair identities. Coalition instruction cards are illustrative paraphrases, not exact saved prompts. The regret-gap formula is a descriptive outcome metric, not an intent label. Primary search uses subset sizes 2–5; all 62 proper subsets are retained for diagnostics. Model in the current experiment is GPT-4o-mini via OpenRouter.

This is an AI-generated raster draft. Network lines and repeated decorative board icons are schematic; the written condition definitions and numeric board counts govern interpretation. Redraw exact connectivity and editable text before final publication. It contains no invented outcome numbers or example transcripts.
