# A versus F: matched-seed comparison

A: shared global board plus private coalition board. F: the same setup with a governance oversight notice appended to every agent’s user prompts. Both assign the pair a coalition objective. The notice is prompt-only; it introduces no actual enforcement. Colored circles and lines link the same seed across conditions; white diamonds and dashed black lines indicate equal-weight means across seeds. Seeds: 101, 102, 103, 104, 105.

Panels show whole-team reward, the same within-seed reference pair’s regret gap, and the population SD of regret gaps across all 15 pairs in each run. A positive reference-pair gap means outsiders have higher mean unilateral regret than the pair. The pair is assigned the coalition objective in both conditions. Pair-gap SD describes outcome dispersion within a run; it is not uncertainty across seeds. Pairs overlap and are not independent observations. No inferential error bars or significance claims.
