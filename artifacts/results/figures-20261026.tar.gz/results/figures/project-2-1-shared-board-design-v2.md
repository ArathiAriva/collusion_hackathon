# Shared-board study design illustration v2

Generated October 24, 2026 following the user's updated setup. Sources: results/SHARED_BOARD_PILOT_PLAN.md; paper_shared_board/README.md; shared-board YAML configs; run.py network construction, extra_channel_members and coalition_prompt settings; current PROJECT_LOG.md.

All conditions have one six-member global board. A/B assign coalition instructions; A/C add one pair-only board; D has global only; E adds all 15 pair boards to global. Total boards 2/1/2/1/16. A–D are the instructions × private-board 2×2 core, E an extension. Image describes the seed-1 development pilot, not the historical endpoint/interior protocol or five-seed evaluation.

The image is an AI-generated raster schematic. Numeric robot labels are illustrative identifiers, not speaking order. Coalition objective cards paraphrase assigned instructions. Edges in E summarize pairwise access; board counts and membership definitions are authoritative. No outcome data or claimed results appear. No pilot process, source code, config, or experiment artifact modified.

v2 replaces the earlier endpoint/interior illustration for this revised protocol. Private-board icon duplication in the first shared-board generation was corrected to one shared pair board in each A/C cell before saving this version.
