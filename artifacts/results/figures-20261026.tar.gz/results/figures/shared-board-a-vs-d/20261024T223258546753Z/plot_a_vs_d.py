"""Matched-seed A–D comparison of the completed shared-board experiment."""
import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean, median
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'results/ae-batches/shared-board-eval-v2-seeds101-105/analysis/results.json'


def main():
    data=json.loads(SOURCE.read_text());assert data['status']=='completed'
    lookup={(r['condition'],r['seed']):r for r in data['runs']}
    seeds=[101,102,103,104,105]
    metrics=[('primary_regret_gap','Best subset (size 2–5)','Regret gap'),
             ('reference_pair_regret_gap','Fixed pair¹','Regret gap'),
             ('joint_reward','Whole team','Total reward')]
    out=ROOT/'results/figures/shared-board-a-vs-d'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True,exist_ok=False)
    summary={};rows=[]
    for metric,_,_ in metrics:
        av=[lookup['A',s][metric] for s in seeds];dv=[lookup['D',s][metric] for s in seeds];diff=[a-d for a,d in zip(av,dv)]
        summary[metric]=dict(A_mean=mean(av),D_mean=mean(dv),mean_difference=mean(diff),median_difference=median(diff),
            positive=sum(v>1e-9 for v in diff),negative=sum(v< -1e-9 for v in diff),
            paired=dict(zip(seeds,diff)),leave_one_out_means={str(s):mean(v for i,v in enumerate(diff) if seeds[i]!=s) for s in seeds})
    for s in seeds:
        row={'seed':s}
        for metric,_,_ in metrics:
            row['A_'+metric]=lookup['A',s][metric];row['D_'+metric]=lookup['D',s][metric]
            row['A_minus_D_'+metric]=lookup['A',s][metric]-lookup['D',s][metric]
        rows.append(row)
    with (out/'paired_scores.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (out/'summary.json').write_text(json.dumps(dict(source=str(SOURCE),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),metrics=summary),indent=2)+'\n')
    shutil.copyfile(__file__,out/'plot_a_vs_d.py')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    acolor='#2463a6';dcolor='#8456a2';x=np.arange(5)
    fig,axes=plt.subplots(1,3,figsize=(12.5,4.7))
    fig.subplots_adjust(left=.065,right=.985,bottom=.18,top=.73,wspace=.34)
    for ax,(metric,title,ylabel) in zip(axes,metrics):
        av=[lookup['A',s][metric] for s in seeds];dv=[lookup['D',s][metric] for s in seeds]
        for i,(a,d) in enumerate(zip(av,dv)):ax.plot([i-.11,i+.11],[a,d],color='#b9b9b9',lw=1.4,zorder=1)
        ax.scatter(x-.11,av,color=acolor,s=48,zorder=3,label='A')
        ax.scatter(x+.11,dv,color=dcolor,s=48,zorder=3,label='D')
        if metric!='joint_reward':ax.axhline(0,color='#777777',lw=.8,zorder=0)
        ax.set_xticks(x,[str(s) for s in seeds]);ax.set_xlabel('Matched seed');ax.set_ylabel(ylabel)
        ax.set_title(f'{title}\nMean A {mean(av):.2f}  |  D {mean(dv):.2f}',fontsize=11,pad=12)
        ax.set_xlim(-.45,4.45)
    handles=[Line2D([],[],marker='o',color=acolor,ls='',label='A: coalition instructions + private pair board'),
             Line2D([],[],marker='o',color=dcolor,ls='',label='D: shared board only; no coalition instructions')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.91),ncol=2,frameon=False,fontsize=10)
    fig.suptitle('A versus D: five matched Jira instances',fontsize=15,y=.99)
    fig.text(.5,.025,'Both have a global board.  ¹Same identities in both conditions; only A assigns a coalition.  Lines connect the same seed.',ha='center',fontsize=9)
    for ext in ('png','svg'):fig.savefig(out/f'a-vs-d-paired.{ext}',dpi=180)
    plt.close(fig)
    # Separate effect plot: no overlap of unpaired error bars, no dropped seeds.
    fig,axes=plt.subplots(1,3,figsize=(12.5,4.7));fig.subplots_adjust(left=.065,right=.985,bottom=.17,top=.76,wspace=.36)
    for ax,(metric,title,_) in zip(axes,metrics):
        vals=[summary[metric]['paired'][s] for s in seeds]
        for i,v in enumerate(vals):
            ax.plot([0,v],[i,i],color='#b9b9b9',lw=1.3)
            ax.scatter(v,i,color=acolor if v>=0 else dcolor,s=48,zorder=3)
        ax.scatter(mean(vals),5.3,marker='D',s=65,color='black',zorder=4)
        ax.axvline(0,color='#777777',lw=.9);ax.axhline(4.65,color='#dddddd',lw=.8)
        ax.set_yticks([0,1,2,3,4,5.3],[str(s) for s in seeds]+['Mean']);ax.invert_yaxis()
        ax.set_title(f'{title}\nMean difference {mean(vals):+.2f}',fontsize=11,pad=12)
        ax.set_xlabel('A − D (points)');ax.margins(x=.15)
    fig.suptitle('Paired differences: positive means higher in A',fontsize=15,y=.98)
    fig.text(.5,.025,'Every seed retained; black diamond = mean.  ¹The same pair is assigned only in A.\nHigher regret gap is relative advantage, not necessarily better team performance.',ha='center',fontsize=9)
    for ext in ('png','svg'):fig.savefig(out/f'a-minus-d.{ext}',dpi=180)
    plt.close(fig)
    rel=out.relative_to(ROOT/'results')
    text='''# A versus D — shared-board comparison

A has coalition instructions and a private board for the selected pair. D has neither. Both have the same global board, task instances, agents, costs, model and speaking order. This comparison changes **two factors together**; it cannot isolate the private board alone. A−B isolates private access when coalition instructions are present.

Five paired seeds, 101–105; one trajectory per condition/seed. This is an exploratory comparison requested after the experiment. No new inference, seed exclusions, confidence claims or changes to the original primary analysis.

## Paired outcomes

'''
    text+=f'![A and D by matched seed]({rel}/a-vs-d-paired.png)\n\n'
    text+='## Average comparison\n\n| Metric | A | D | Mean A−D | A higher in |\n|---|---:|---:|---:|---:|\n'
    for metric,title,_ in metrics:
        s=summary[metric];text+=f"| {title} | {s['A_mean']:.3f} | {s['D_mean']:.3f} | {s['mean_difference']:+.3f} | {s['positive']}/5 |\n"
    text+='''
The fixed pair is an instructed coalition in A and only a scoring reference in D. Its higher average gap in A is distinct from the maximum over all proper subsets. The maximum-subset search selects different groups in each trajectory; it is not always measuring the selected pair.

A has a higher fixed-pair gap in 4/5 seeds. The primary best-subset gap is higher in A in 3/5, but its mean difference is negative, with a large negative seed-104 difference. Removing seed 104 would reverse that primary mean difference, illustrating sensitivity; it remains included in every reported result. Team reward is higher in A in 3/5 seeds.

'''
    text+=f'![A minus D by seed]({rel}/a-minus-d.png)\n\n'
    text+=f'Data: [paired CSV]({rel}/paired_scores.csv), [summary including leave-one-out checks]({rel}/summary.json). Figures are also available as SVG: [paired outcomes]({rel}/a-vs-d-paired.svg), [paired differences]({rel}/a-minus-d.svg). Source: [full experiment results](shared-board-eval-v2-summary.md).\n'
    (ROOT/'results/a-vs-d-comparison.md').write_text(text)
    print(json.dumps(dict(output=str(out),metrics=summary),indent=2))

if __name__=='__main__':main()
