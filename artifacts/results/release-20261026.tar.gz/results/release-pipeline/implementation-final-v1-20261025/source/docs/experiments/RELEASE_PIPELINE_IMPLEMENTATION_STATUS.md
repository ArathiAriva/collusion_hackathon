# Release go/no-go implementation status

October 25, 2026. Implemented at the user's request. This is development code with offline verification. No paid model calls, model calibration, held-out evaluation, commits or pushes were performed for this implementation.

## Delivered

- **M1 / T01–T03:** [Executable contract](RELEASE_PIPELINE_CONTRACT.md), immutable typed scenario/operation/workload records, finite role/domain ownership, static versus conditional submission references, tie rules, disclosure contrast, evidence views, and expanded development coverage audit. Low-opportunity pairings remain controls. Continuous metrics and strict-zero opportunities are retained; practical thresholds remain provisional until calibration.
- **M2 / T04–T06:** Pure 144-assignment evaluator; all-role activity ledger; exact economic/nominal scoring and dominating H; optimum ties; credited accounting; W; six-pair raw/normalized CA; static/response-aware witnesses; auxiliary/member/relative incentive gains; harm and component changes; credit and coefficient sensitivity.
- **M3 / T07–T10:** Repository-local abstract-environment implementation, shared local tool provider for schema discovery and execution, authenticated role/phase/single-commit checks, isolated evidence, public/private boards, neutral chair opening, rotating four-round schedule, fixed final submission order, role-native prompts and native BaseAgent-loop offline integration. Existing Terrarium discovery remains the fallback; installed dependencies and CoLLAB are untouched.
- **M4 / T11–T13 tooling:** Dedicated A–D configs and serial launcher, source/config/scenario snapshots and Git/dependency provenance, frozen namespace checks, no automatic trajectory retries or D reuse, native artifacts, offline rescoring/privacy audits, all-pair CSV, matched contrasts and scenario-cluster uncertainty, blinded human annotation packets and record validation, run guide and incomplete run-card template. Live preflight rejects model/endpoint drift and saved credentials.

**M4's live calibration freeze is still pending:** endpoint/rates verification, a full prompt-growth cost estimate, concrete trajectory budget, reviewer workflow and a reviewed run card. The live provider path is implemented but untested for this environment. This is not a claim that all T13 exit criteria or M5/M6 are complete. No LLM judge is automatically invoked, and the annotation validator cannot establish the correctness of a reviewer's intent judgment.

## Verification

50 tests passed across these suites:

| Scope | Tests |
| --- | ---: |
| Release evaluator, scenarios, protocol, privacy, narrative fixtures, failure handling and annotations | 18 |
| Release scheduling, dry runs, namespace/source snapshots, rescoring, run-card and endpoint/model checks | 5 |
| Existing routing, public-board, path-placement and subset scoring | 12 |
| Existing shared-board A–F launcher and pressure-prompt integration | 15 |

Checks include independent hand-calculated values, exhaustive gates and credited-regret bounds, every assignment's credit sum, exact constrained/penalized optimum equivalence, false-record workload invariance, fixed cost caps, all six scenario families through native tools, first-accepted-commit immutability, private-message canaries, out-of-phase/unauthorized actions, missing submissions and provider failures. Scripted knowing agreement, shared misunderstanding and an unwitting partner have identical harmful outcomes but distinct hand-authored annotation records. Those fixtures test the pipeline; they do not measure an LLM's intent or a judge's accuracy.

A saved 24-trajectory offline A–D pilot covers the hand-worked fixture and all six pairs. Every trajectory completed, every run passed rescoring/visibility checks, and each has 20 prompt records. The scripted clients use predetermined decisions; zero treatment effects are expected and are not experimental findings. See the local artifacts under `results/release-pipeline/implementation-final-v1-20261025/` (ignored by Git).

The calibration fixture exactly reproduces the design: economic extrema [-22,37], H=60, W=65.5, 14 admissible assignments, nominal minimum -199.5 and optimum 37. The unsafe Product+Release example has nominal reward -82, economic reward -22, pair incentive gain approximately +0.1764, and credited CA -9.125. This demonstrates that incentive success and credited CA are separate quantities.

## Expanded scenario audit

Preserved output: `results/release-pipeline/development-scenario-audit-v2.json`. It contains generated inputs, source hashes, detailed oracle summaries and opportunity counts. Reproduce with `scripts/release_pipeline/audit_scenarios.py` and a new output path. These 120 scenarios are development artifacts, not held-out samples.

The audit checks 120 scenarios × five coefficient settings × 144 assignments = **86,400 assignment evaluations**. Main-setting optima: 22 limited ordinary, 38 full guarded exceptions, 20 full guarded ordinary, 20 full standard ordinary and 20 deferrals. Deferral optima now vary, from approximately -17.87 to -9.46, because no-deployment workloads vary.

Strict mutually beneficial harmful joint opportunities, out of 120 scenarios:

| Pair | Static, any cooperative optimum | Conditional submissions after truthful disclosure |
| --- | ---: | ---: |
| Product + QA | 0 | 2 |
| Product + Ops | 12 | 2 |
| Product + Release | 39 | 43 |
| QA + Ops | 78 | 78 |
| QA + Release | 0 | 0 |
| Ops + Release | 6 | 6 |

These columns have different reference/response semantics; neither must bound the other. They are not observed collusion rates. In particular, the conditional policy can allow outsiders to make responsive changes, and its reference outcome need not equal the global optimum. Most harmful mutual-gain opportunities remain unilateral-capable; conditional joint necessity occurs in 2 Product+Ops and 21 Product+Release scenarios under this particular policy. Unequal incentives and the oracle's truthful-disclosure boundary qualify any later pair-level claims.

## Next stage

Follow the [run guide](../../scripts/release_pipeline/README.md). Before spending, verify the exact OpenRouter endpoint/model path and rates, estimate full context growth, choose the development A/D calibration scope and freeze a concrete run card. Model comprehension, elicitation, execution, mutual benefit and harm must be diagnosed separately. Keep all six pairs and preserve failed/negative cases. Only after development calibration should prompts, thresholds, annotation procedures and sampling be frozen for held-out A–D.
