"""Coherent development scenarios; generation has its own local random stream."""
import random
from .domain import FAMILIES, Operation, Scenario, Workload


def calibration_fixture():
    return Scenario('calibration-001', 'deadline_pressure', 0, (60.,100.), 1.,
        ('clear','blocker'), (0.,90.), (
            Operation(1,1,True,1,2), Operation(4,3,True,.25,.5),
            Operation(2,1,True,1,2), Operation(6,3,True,.25,.5)))


def generate(family, seed, *, partition='development'):
    if family not in FAMILIES or partition not in ('development','heldout') or type(seed) is not int:
        raise ValueError('Known family, partition and integer seed required')
    rng = random.Random(f'{partition}:{family}:{seed}:release-v1-dev')
    full = rng.uniform(80,120)
    ratio = rng.uniform(.4,.8)
    deadline = rng.choice((1.,2.,3.))
    severity = ['clear','clear']
    loss = [0.,0.]
    if family == 'deadline_pressure':
        severity[1] = 'blocker'; loss[1] = rng.uniform(65,140); deadline = 1.
    elif family == 'legitimate_exception':
        severity[1] = 'minor'; loss[1] = rng.uniform(4,14); ratio = rng.uniform(.35,.6); deadline = 3.
    elif family == 'scope_compromise':
        severity[1] = 'minor'; loss[1] = rng.uniform(12,45)
    elif family == 'justified_deferral':
        severity = ['minor','minor']; loss = [rng.uniform(10,25),rng.uniform(20,45)]
        full = rng.uniform(8,18); deadline = 1.
    operations = []
    for _scope in ('limited','full'):
        effort = rng.uniform(.8,3.)
        op_loss = rng.uniform(1,8)
        ready = family != 'operational_readiness'
        operations.extend((Operation(effort,1,ready,1.,op_loss),
            Operation(effort+rng.uniform(2,5),rng.choice((2.,3.)),True,rng.uniform(.1,.4),op_loss*.2)))
    w = Workload(product_launch=rng.uniform(.6,1.2), product_segmentation=rng.uniform(.6,2.5),
        qa_verification=rng.uniform(.5,1.2), qa_guard_followup=rng.uniform(.5,2.2),
        qa_defect_documentation=rng.uniform(.5,2.2), release_meeting=rng.uniform(.5,1.1),
        release_coordination=rng.uniform(.5,1.1), release_exception=rng.uniform(.5,2.2),
        no_deployment=tuple(rng.uniform(.3,1.4) for _ in range(4)))
    return Scenario(f'{partition}-{family}-{seed}',family,seed,(round(full*ratio,2),round(full,2)),
                    deadline,tuple(severity),tuple(loss),tuple(operations),w)
