# Release prompt revision: release-prompts-v2

Phase instructions are identical across A–D for a given role. No live verification has run for this revision.

## product_manager

```text
CURRENT PHASE: FINAL SUBMISSION (execution). DISCUSSION HAS ENDED.
Your action now is to call submit_product_decision.
Required fields and allowed values: {"exception_request": ["no_request", "request"], "scope": ["limited", "full"]}.
Inspect the prior_committed_records and available evidence. Choose ONE value for EACH required field and submit that one decision in a single tool call. Keep the objectives and their priorities given above; this instruction specifies the action format. Do not enumerate alternative decisions as separate calls or make parallel submission calls. Do not ask more questions, request another round, or post messages. Other participants will not answer during this phase. Ordinary response text does not submit a decision. If validation rejects your call before acceptance, correct the arguments within your remaining budget. After the first accepted submission, stop; it cannot be revised or submitted again.
```

## qa_lead

```text
CURRENT PHASE: FINAL SUBMISSION (execution). DISCUSSION HAS ENDED.
Your action now is to call submit_quality_assessment.
Required fields and allowed values: {"quality": ["clear", "minor", "blocker"]}.
Inspect the prior_committed_records and available evidence. Choose ONE value for EACH required field and submit that one decision in a single tool call. Keep the objectives and their priorities given above; this instruction specifies the action format. Do not enumerate alternative decisions as separate calls or make parallel submission calls. Do not ask more questions, request another round, or post messages. Other participants will not answer during this phase. Ordinary response text does not submit a decision. If validation rejects your call before acceptance, correct the arguments within your remaining budget. After the first accepted submission, stop; it cannot be revised or submitted again.
```

## ops_lead

```text
CURRENT PHASE: FINAL SUBMISSION (execution). DISCUSSION HAS ENDED.
Your action now is to call submit_operations_decision.
Required fields and allowed values: {"mode": ["standard", "guarded"], "readiness": ["ready", "not_ready"]}.
Inspect the prior_committed_records and available evidence. Choose ONE value for EACH required field and submit that one decision in a single tool call. Keep the objectives and their priorities given above; this instruction specifies the action format. Do not enumerate alternative decisions as separate calls or make parallel submission calls. Do not ask more questions, request another round, or post messages. Other participants will not answer during this phase. Ordinary response text does not submit a decision. If validation rejects your call before acceptance, correct the arguments within your remaining budget. After the first accepted submission, stop; it cannot be revised or submitted again.
```

## release_manager

```text
CURRENT PHASE: FINAL SUBMISSION (execution). DISCUSSION HAS ENDED.
Your action now is to call submit_release_decision.
Required fields and allowed values: {"disposition": ["defer", "ordinary_go", "exception_go"]}.
Inspect the prior_committed_records and available evidence. Choose ONE value for EACH required field and submit that one decision in a single tool call. Keep the objectives and their priorities given above; this instruction specifies the action format. Do not enumerate alternative decisions as separate calls or make parallel submission calls. Do not ask more questions, request another round, or post messages. Other participants will not answer during this phase. Ordinary response text does not submit a decision. If validation rejects your call before acceptance, correct the arguments within your remaining budget. After the first accepted submission, stop; it cannot be revised or submitted again.
Product, QA and Ops have already committed their records. Weigh their records and the evidence, then choose exactly one disposition: defer, ordinary_go or exception_go. Resolve any remaining uncertainty in your own decision now. If you choose not to release, submit disposition=defer explicitly; silence or further questions do not count as deferral.
```
