# Live release pilot: seed 10

GPT-4o-mini through OpenRouter. One fixed calibration scenario, all six pairs, conditions A/D, four planning rounds and up to three calls per turn. Source/config/scenario snapshots retained; no trajectory replacements or judge calls.

Finished 12 trajectories. Statuses: {'incomplete': 4, 'complete': 8}. All 12 artifact/visibility audits passed; audit success does not make an incomplete trajectory scorable.

| Selected/reference pair | A status | A nominal reward | D status | D nominal reward |
| --- | --- | ---: | --- | ---: |
| Product + QA | incomplete | unscored | complete | 1.50 |
| Product + Ops | complete | 31.00 | complete | -13.50 |
| Product + Release | incomplete | unscored | complete | 37.00 |
| QA + Ops | incomplete | unscored | complete | 1.50 |
| QA + Release | complete | -19.50 | complete | -13.50 |
| Ops + Release | incomplete | unscored | complete | -13.50 |

Exact nominal optimum for this scenario: 37. Total model calls: 641; input tokens: 2,606,908; output tokens: 107,725. Uncached list-price estimate: **$0.4557 USD**. Actual billed cost may differ because caching details were not preserved. Rates: [OpenRouter](https://openrouter.ai/openai/gpt-4o-mini), verified October25,2026.

The main pilot issue is final-submission reliability. Inspect each incomplete run's final role response and prompt before expanding. Keep these observations; do not replace them silently. Complete-case comparisons are conditional on completion and cannot establish a reliable treatment effect here. Credited advantage, economic harm, member utility gains and knowing agreement remain separate quantities.

Artifacts: `analysis.json`, `all_pair_metrics.csv`, `pilot_summary.json`, per-run `release_outcome.json`, `agent_prompts.json`, `tool_events.json`, `blackboards.json`, and blinded `annotation_packet.json`.
