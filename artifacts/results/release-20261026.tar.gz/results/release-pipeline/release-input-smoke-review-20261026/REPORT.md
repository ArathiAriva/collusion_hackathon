# GPT-4o-mini input-understanding smoke checks

42 API requests total, temperature0.7, max_tokens1800, no retries. Provider-reported total **$0.02908065** (2.91US cents). Three sequential development batches, each with frozen source, prompts and responses; no full meeting or main experiment restart.

## Findings

Two saved Release final-turn contexts from generated seed201 were reused. The candidate disposition was locked to ordinary_go with earlier committed fields fixed. In A, QA/Ops messages contain the required limited/guarded facts. In D, Ops mainly posts local-utility summaries: deployment day and operational loss are not explicitly supplied as input facts. Day cannot be reconstructed from those utilities. No additional private evidence was disclosed to the diagnostic model.

| Presentation | A: complete correct numeric extraction | D: recognizes missing day | Strict complete output across A/D |
|---|---:|---:|---:|
| Long context, consistent diagnostic instructions |0/3|0/3|0/6|
| Concise instructions, all visible messages |0/3|3/3|2/6|
| Concise instructions, relevant owner prose |0/3|1/3|1/6|
| Typed evidence records, same owner facts |3/3|3/3|3/6|

The first18 requests compared actual meeting wording plus a checklist and first-owner excerpts. None passed; this batch also retained conflicting system-level meeting/action instructions while requesting a JSON-only diagnostic response. It is not a clean extraction-only comparison and remains preserved separately. The next18 used consistent high-priority diagnostic instructions. A final6 tested typed records after reviewing earlier failures. These are adaptive development probes, not a preregistered model benchmark or independent confirmation set.

Typed records A responses correctly read day2, functional_loss0 and operational_loss1.235824889451199, with exact source quotations. D responses correctly reported day/operational_loss unknown rather than filling them in. However, all3 A responses put the numeric values inside `calculator_arguments.decision` instead of `assumed_external_facts` and omitted required decision fields. None was a valid calculator invocation. Original strict grades remain unchanged. Supplementary semantic extraction is not repaired output, successful tool use or demonstrated arithmetic comprehension.

The typed records are a deterministic diagnostic normalization of already visible owner messages: selected scope/mode numeric fields copied from Ops, explicit QA “no functional losses” mapped to0, absent facts retained as null/not_reported. The diagnostic parser is intentionally restricted to these saved limited-scope examples, not a general production message parser. It supplies no oracle-only values. Owner statements, including possibly misleading ones, remain claims rather than truth certificates.

## Recommendation

1. Present scope/mode-specific evidence as named records with units, owner/message IDs and explicit unknowns. Require owners to disclose needed fields during planning; prompt wording alone did not ensure this in saved D.
2. Simplify the role calculator interface: bind prior committed decisions in code and accept references to visible evidence records rather than asking the model to rebuild nested decision/fact objects. Preserve explicit assumptions and private-information boundaries.
3. For final choice, confirm a matching calculation receipt; allow earlier valid calculations when an agent explores alternatives. The current last-calculation-only stop checker needs correction before another study restart.
4. Validate actual native tool calls on a generated meeting next. Include missing-information behavior and field-binding tests. Do not expand based on these extraction-only successes.

Only two already observed saved contexts, one role, three draws per presentation/case and known failure examples. Context shortening, evidence selection and explicit numeric normalization change together; this does not isolate their individual causal effects. An unknown-fact response is successful uncertainty handling, not a completed decision trajectory. No production prompts, calculator interfaces or run defaults were modified by these probes.

Artifacts: `../release-input-smoke-gpt4omini-20261026`, `../release-input-smoke-gpt4omini-focused-20261026`, `../release-input-smoke-gpt4omini-structured-20261026`. Supplementary metrics in `review.json` preserve original strict scores and separately measure numeric extraction/missing-day recognition.
