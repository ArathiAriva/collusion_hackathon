#!/usr/bin/env python3
"""Offline-first, eight-call model comparison; no changes to meeting experiments."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'colosseum'))
from experiments.collusion.release_pipeline.comprehension import VERSION, build_packets, score_answer
from experiments.collusion.release_pipeline.domain import ROLES, digest
from experiments.collusion.release_pipeline.runner import write_json

MODELS={
    'openai/gpt-4o-mini':{'max_tokens':6000,'temperature':0},
    'openai/gpt-6-luna':{'max_completion_tokens':6000,'reasoning_effort':'none'},
}


def validate_card(card, frozen):
    if (card.get('diagnostic_version')!=VERSION or card.get('packet_hash')!=digest(frozen) or
        card.get('authorized_requests')!=8 or card.get('models')!=MODELS or
        card.get('base_url')!='https://openrouter.ai/api/v1' or
        card.get('retry_policy')!='none' or not card.get('freeze_id')):
        raise ValueError('Card must freeze exact packets, both models/parameters, eight calls and no retries')
    for model in MODELS:
        rates=card.get('rates',{}).get(model,{})
        if not all(type(rates.get(k)) in (float,int) and rates[k]>=0 for k in ('input_per_million','output_per_million')) or not rates.get('verified_date') or not rates.get('source_url'):
            raise ValueError('Verified endpoint rates required for both models')
    if type(card.get('resource_estimate_usd')) not in (int,float) or card['resource_estimate_usd']<=0:
        raise ValueError('Positive resource estimate required')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed',type=int,default=11)
    parser.add_argument('--batch-id')
    parser.add_argument('--live',action='store_true')
    parser.add_argument('--run-card',type=Path)
    args=parser.parse_args()
    frozen=build_packets(args.seed)
    if not args.live:
        print(json.dumps({'diagnostic_version':VERSION,'packet_hash':digest(frozen),
            'models':MODELS,'requests':8,'candidate_answers':48,'max_output_tokens':48000,
            'prompt_bytes_by_role':{r:len(json.dumps(p).encode()) for r,p in frozen['packets'].items()},
            'mode':'offline-preflight'},indent=2))
        return
    if not args.run_card or not args.batch_id or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',args.batch_id):
        parser.error('Live use requires a new batch-id and frozen run-card')
    card=json.loads(args.run_card.read_text());validate_card(card,frozen)
    from poseidon_compute import llm_config
    if llm_config.base_url().rstrip('/')!=card['base_url']:
        raise ValueError('Configured endpoint differs from frozen card')
    output=ROOT/'results/release-pipeline'/args.batch_id
    output.mkdir(parents=True,exist_ok=False)
    import run as meeting_launcher
    hashes=meeting_launcher.source_snapshot(output/'source')
    write_json(output/'frozen_packets_and_reference.json',frozen)
    shutil.copy2(args.run_card,output/'run_card.json')
    manifest={'diagnostic_version':VERSION,'created_utc':datetime.now(timezone.utc).isoformat(),
              'packet_hash':digest(frozen),'source_hashes':hashes,'status':'running',
              'planned_requests':8,'completed':[],'model_seed':None,
              'note':'One response per role/model; six correlated candidates each. Full disclosure diagnostic, no tools or coalition objectives.'}
    write_json(output/'manifest.json',manifest)
    client=llm_config.make_client(max_retries=0,timeout=90)
    reports=[]
    for model,params in MODELS.items():
        model_dir=output/model.replace('/','--');model_dir.mkdir()
        for role,packet in frozen['packets'].items():
            request={'model':model,'messages':[{'role':'system','content':packet['system']},
                {'role':'user','content':packet['user']}],'response_format':{'type':'json_object'},**params}
            write_json(model_dir/f'{role}.request.json',request)
            record={'model':model,'role':role}
            try:
                response=client.chat.completions.create(**request)
                raw=response.model_dump(mode='json')
                write_json(model_dir/f'{role}.response.json',raw)
                text=response.choices[0].message.content or ''
                score=score_answer(text,frozen['references'][role],role)
                usage=raw.get('usage') or {}
                rates=card['rates'][model]
                estimate=(usage.get('prompt_tokens',0)*rates['input_per_million']+
                          usage.get('completion_tokens',0)*rates['output_per_million'])/1e6
                record.update(status='responded',finish_reason=response.choices[0].finish_reason,
                    returned_model=response.model,score=score,usage=usage,uncached_estimate_usd=estimate)
            except Exception as exc:
                # Do not expose SDK objects/headers or credential-bearing errors.
                record.update(status='request_error',error_type=type(exc).__name__,http_status=getattr(exc,'status_code',None))
            write_json(model_dir/f'{role}.scored.json',record)
            reports.append(record)
            manifest['completed'].append({'model':model,'role':role,'status':record['status']})
            write_json(output/'manifest.json',manifest)
            print(json.dumps({'model':model,'role':role,'status':record['status'],
                              'fully_correct_cases':record.get('score',{}).get('fully_correct_cases')}),flush=True)
            if record.get('http_status') in (401,403):
                break
        if reports[-1].get('http_status') in (401,403):
            break
    summary={}
    for model in MODELS:
        rows=[r for r in reports if r['model']==model]
        summary[model]={'planned_responses':4,'responded':sum(r['status']=='responded' for r in rows),
            'valid_format':sum(r.get('score',{}).get('format_ok',False) for r in rows),
            'planned_candidates':24,
            'fully_correct_candidates':sum(r.get('score',{}).get('fully_correct_cases',0) for r in rows),
            'roles_with_correct_ranking':sum(r.get('score',{}).get('ranking_correct',False) for r in rows),
            'correct_counts':{k:sum(r.get('score',{}).get('correct_counts',{}).get(k,0) for r in rows)
                for k in ('deployed','on_time_deployment','benefit','components_correct','total_workload',
                          'workload_penalty','raw_utility','normalized_utility','arithmetic_consistent')},
            'uncached_estimate_usd':sum(r.get('uncached_estimate_usd',0) for r in rows)}
    write_json(output/'summary.json',{'models':summary,'responses':reports,
        'limitations':['One response per role/model on one fixed build; candidate answers are correlated.',
                       'Full required facts explicitly disclosed; not a test of meeting information access.',
                       'No tools, no coalition objective, no behavioral collusion or causal model-quality claim.',
                       'GPT-4o-mini temperature0; Luna reasoning_effort none and no temperature parameter.',
                       'Tolerance1e-5; malformed/missing cases are not dropped; no response repair/retry.']})
    manifest['status']='complete' if len(reports)==8 and all(r['status']=='responded' for r in reports) else 'finished-with-errors'
    write_json(output/'manifest.json',manifest)
    print(json.dumps({'batch':str(output),'models':summary}),flush=True)


if __name__=='__main__':
    main()
