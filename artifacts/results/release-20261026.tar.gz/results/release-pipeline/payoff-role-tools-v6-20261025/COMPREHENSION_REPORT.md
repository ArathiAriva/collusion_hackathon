# Tool-assisted payoff diagnostic

Eight role/model responses, 16 model requests including tool-result continuations; no retries. Maximum authorized24. Each response covers six correlated candidates on the fixed build. Frozen source, packets, raw requests/responses and exchanges retained. Provider-reported total$0.01443509.

| Measure | GPT-4o-mini | GPT-6 Luna |
|---|---:|---:|
| Correct benefit |24/24|23/24|
| Correct workload |24/24|23/24|
| Correct raw utility |24/24|23/24|
| Arithmetic consistent |24/24|24/24|
| Correct deployment |24/24|24/24|
| Correct timing classification |22/24|24/24|
| Entire ranking correct |3/4 roles|3/4 roles|
| Strict fully correct cases |22/24|23/24|

Earlier tool-free raw utilities were2/24 and10/24. This comparison changes prompt wording and tool access together; it does not isolate their effects. Luna used reasoning_effort=none. One disclosed fixture is not general capability evidence.

GPT4 QA returned false timing for two on-time deployments; its payoff numbers were correct. The QA calculator returns null timing because timing is not needed for QA's own payoff; diagnostic instructions explicitly ask models to derive timing separately. GPT4 Ops had correct numerical utilities but an incorrect ranking.

Luna QA passed scope=limited to the calculator for C4, whose supplied candidate was full, and then reported that limited-scope payoff. Own evidence correctly took precedence over the supplied loss. This is a candidate-to-call translation error, not calculator arithmetic. Its incorrect ranking follows the wrong candidate payoff. All other Luna cases were fully correct.

Strict acceptance (every candidate and ranking correct for every role) remains unmet. No repeated adaptive inference or broad experimental expansion was performed. A separate single meeting smoke tests actual optional tool use, not comprehension certification.
